<?php

$username = $_POST['username'];
$password = $_POST['password'];

if(!empty($username) || !empty($password)){
    $host = "localhost";
    $dbUsername = "root";
    $dbpassword = "";
    $dbname = "abc";

    $conn = new mysqli($host, $dbUsername, $dbpassword, $dbname);
    if(mysqli_connect_error()){
        die('Connect Error('. mysqli_connect_error().')'. mysqli_connect_error());
    }else{
        $stmt = $conn->prepare(" INSERT INTO abc (username , password) values (?, ?)");
            $stmt->bind_param("ss",$username, $password);
            $stmt->execute();
            echo "login succcessfully...";
           
    }
    $stmt->close();
    $conn->close();
} else{
    echo "all fields are required";
    die();
}